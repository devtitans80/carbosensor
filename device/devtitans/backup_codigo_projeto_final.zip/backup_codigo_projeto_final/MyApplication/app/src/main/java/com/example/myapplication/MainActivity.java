package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.util.List;
import android.app.AlarmManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.RemoteException;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "DevTITANS.CarbosensorApp";
    private Button botaoIniciar;
    private boolean pararExecucao = false;
    private TextView textStatus, textSensor, textContador ;
    private SensorManager manager;

    private ImageView imgCirculo;
    private Drawable drawableGreen, drawableRed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textStatus   =  findViewById(R.id.textStatus);                      // Acessa os componentes da tela
        textSensor   =  findViewById(R.id.textSensor);
//        botaoIniciar =  findViewById(R.id.buttonIniciar);

        imgCirculo   =  (ImageView) findViewById(R.id.imgCirculo);
        drawableGreen= getResources().getDrawable(R.drawable.circulo_vermelho);
        drawableRed= getResources().getDrawable(R.drawable.circulo);

        textStatus.setText("Aguardando ...");
        textStatus.setTextColor(Color.parseColor("#c47e00"));

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensorList = manager.getSensorList(Sensor.TYPE_DEVICE_PRIVATE_BASE);

        // O sensor de luminosidade padrão vai ser o primeiro da lista, por isso o SmartLamp é o segundo
        Sensor sensor = sensorList.get(0);

        Log.println(Log.INFO, "LIGHT_TEST", sensorList.toString());

        manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (manager != null) {
            manager.unregisterListener(listener);
        }
    }

    private SensorEventListener listener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            // The value of the first subscript in the values array is the current light intensity
            float value = event.values[0];

            updateAll(value);
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }

    };

    public void updateAll(float senMq7) {
        Log.d(TAG, "Atualizando dados do dispositivo ...");

        //   int ppm = 400 / 1023;
        textStatus.setText("Conectado");
        textStatus.setTextColor(Color.parseColor("#6d790c"));
        // int co = ppm * senMq7;
        textSensor.setText(String.valueOf(senMq7));
        if(senMq7<450.0) {
            imgCirculo.setImageDrawable(drawableRed);
        }else{
            imgCirculo.setImageDrawable(drawableGreen);

        }

    }
}